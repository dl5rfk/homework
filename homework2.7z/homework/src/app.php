<?php

namespace tore;

use SQLite3;

 /**
  * Serves as the application container.
  * 
  * The application container has a local SQLite3 database.
  */
class App {

	/**
	 * @var array the configuration array
	 */
	private $_config;

	/**
	 * @var SQLite3 the database handle
	 */
	private $_db;

	/**
	 * @param array $config configuration array
	 * @return void
	 */
	public function __construct(array $config) {
		$this->_config = (object)$config;
	}

	/**
	 * Initializes the object.
	 * @return void
	 */
	public function init() {
		$this->_db = new SQLite3($this->_config->dbpath);
	}

	/**
	 * Runs an SQL-query and returns the result as array.
	 * This method should fetch all the rows from the query
	 * and use numeric fetching.
	 * @param string $query the SQL-query to be executed
	 * @param array $params the bind variables to be defined
	 * @return array the result of the SQL-query
	 */
	public function sqlquery(string $query, array $params = []): array {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * Runs a DML SQL-statement.
	 * This method should be used for insert/update/delete statements.
	 * @param string $query the SQL-query to be executed
	 * @param array $params the bind variables to be defined
	 * @return void
	 */
	public function sqlexecute(string $query, array $params = []) {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	* Fetches the contents of an URL using CURL.
	* @param string $url the url to be fetched
	* @return string the content of the url
	*/
	public static function get_url_data(string $url): string {	
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method converts the XML contents of ECB Rate data to array.
	 * The timeperiod should be converted to unix timestamp, the OBS-Value 
	 * into double.
	 * @return array Converted rate data
	 */
	public function convert_to_array(string $contents): array {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * Fetches the URLs in a loop and creates an array.
	 * The fetched URLs using get_url_data_method contain XML-Data which must be converted
	 * to an array using the convert_to_array method.
	 * @param array $urls the list of urls to be fetched
	 * @return array the combined ECB rate data
	 */
	public static function gather_urls_data(array $urls): array {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method fetches the rates data from the ECB website and returns it as array.
	 * @return array Rates data from the ECB website
	 */
	public static function get_web_data(): array {
		$urls = [
			'USD' => "https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/usd.xml",
			'CAD' => "https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/cad.xml",
		];	
		return self::gather_urls_data($urls);
	}

	/**
	 * This method returns the exchange_rate table data.
	 * 
	 * A header row containing ["Date", "USD", "CAD"] should be prepended to the data. The rows
	 * must be in ascending order.
	 * @return array Rates data from the exchange_rate table
	 */
	public function get_rates_data(): ?array {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method checks if the timestamp exists in the exchange_rate table.
	 * @param int $timestamp The value to look up
	 * @return bool Returns true if the timestamp exists.
	 */
	public function rate_timestamp_exists(int $timestamp): bool {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method merges the rates data into the database.
	 * 
	 * The header of the array to be imported should be skipped. The import array
	 * has the 3 columns [timestamp, usd, cad]. Each row is only inserted if the timestamp of the row
	 * does not exist in the local table using **rate_timestamp_exists** method. Transactions can be used
	 * to speed up the SQL-operations. 
	 * @param array $data Rates data to be merged in the database.
	 * @return void
	 */
	public function merge_rates_data(array $data) {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method returns the maximum timestmap in the exchange_rate table.
	 * @return int Returns the maximum timestamp value
	 */
	public function max_rates_timestamp(): ?int {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method deletes all the rows in the exchange_rate table.
	 * @return void
	 */
	public function reset_rates_data() {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

	/**
	 * This method places the rates data into an excel sheet. 
	 * 
	 * The timestamp information must be converted into an excel format. The column dimensions
	 * can be optionally set to autowidth.
	 * @return void
	 */
	public static function set_excel_data(array $data, &$sheet) {
		/*
		 * TO BE IMPLEMENTED
		 */
	}

}