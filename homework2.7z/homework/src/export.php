<?php
/**
 * Exports the contents of the exchange_rate table as excel spreadsheet.
 *
 * This script is used to export the exchange rates into an excel spreadsheet. It does not alter the data 
 * in the table and only queries it. Headers are included in the data.
 */

require(dirname(__FILE__) . '/../vendor/autoload.php');
require_once(dirname(__FILE__) . "/bootstrap.php");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use tore\App;

$data = $app->get_rates_data();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle("ExportData");

App::set_excel_data($data, $sheet);

$timestamp = date('Ymd_His');
$filename = "export_${timestamp}.xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment;filename=\"${filename}\"");
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');