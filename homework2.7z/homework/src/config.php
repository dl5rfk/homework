<?php
/**
 * Configures the application.
 *
 * This script is used to configure the application.
 */

return [
	'dbpath' => dirname(__FILE__) . "/../data/rates.db",
];