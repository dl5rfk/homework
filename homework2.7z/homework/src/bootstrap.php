<?php
/**
 * Bootstraps the application.
 *
 * This script is used to read the config file and initialize the application.
 */

require_once(dirname(__FILE__) . "/app.php");

use tore\App;

$config = require(dirname(__FILE__) . "/config.php");
$app = new App($config);
$app->init();