<?php
/**
 * Outputs the rates data as JSON.
 *
 * This script is used to print the rates data as JSON. It checks the maximal rate date in the local table and if 
 * it is outdated, the rate data from web is fetched and merged into the local table.
 */

require_once(dirname(__FILE__) . "/bootstrap.php");

use tore\App;

header('Content-Type: application/json; charset=utf-8');
$max_rates_timestamp = $app->max_rates_timestamp();
$yesterday_timestamp = strtotime("yesterday") * 1000;

if ($max_rates_timestamp === null || $max_rates_timestamp < $yesterday_timestamp) {
	$data = App::get_web_data();
	$app->merge_rates_data($data);
}
else {
	$data = $app->get_rates_data();
}
print(json_encode($data));