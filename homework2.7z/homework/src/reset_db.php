<?php
/**
 * Resets the exchange_rate table in the sqlite database.
 *
 * This script is useful to test the merging of data.
 */

require_once(dirname(__FILE__) . "/bootstrap.php");

$app->reset_rates_data();