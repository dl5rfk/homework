<?php
/**
 * Serves the application.
 *
 * This script is used to visualize the exchange rate data.
 */
  
require_once(dirname(__FILE__) . "/src/bootstrap.php");
?>
<html>
  <head>
    <meta charset="utf-8" />
    <title>ECB reference exchange rates, USD / CAD &#8660; Euro</title>
    <link rel="stylesheet" href="assets/styles.css">
    <script type="text/javascript" src="//www.gstatic.com/charts/loader.js"></script>
	  <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart', 'table']});
      google.charts.setOnLoadCallback(drawAll);

      function drawAll() {
        var arr = JSON.parse($.ajax({
              url: "src/get_data.php",
              dataType: "json",
              async: false,
              data: {_dt: (new Date()).getTime()},
              timeout: 90000
            }).responseText);
        var data = google.visualization.arrayToDataTable(
          arr.map(function(item) {
              return [new Date(item[0]), item[1], item[2]];
          })
        );

        var options = {
          title: 'ECB reference exchange rates, USD / CAD \u21D4 Euro',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
		    var table = new google.visualization.Table(document.getElementById('table_div'));

        chart.draw(data, options);
		    table.draw(data, {showRowNumber: true, sortColumn: 0, sortAscending: false, width: '100%', height: '100%'});
        var el = document.getElementById('splash');
        el.parentNode.removeChild(el);
      }
    </script>
  </head>
  <body>
    <div id="splash"><div class="loader"></div></div>
    <div id="curve_chart"></div>
    <div id="buttons">
      <a href="src/export.php" class="btn" target="_blank">Export</a>
    </div>
  	<div id="table_div"></div>
  </body>
</html>