Dear Applicant, 

attached you will find a skeleton of a web application. Your task is to implement the missing methods in the src/app.php file. 

The application fetches European Central Bank (ECB) rate data for USD and CAD and visualizes it using a chart and a table. The rate data is publicly accessible and is in XML format. 

Following URLs are used to fetch the data:
USD: https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/usd.xml
CAD: https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/cad.xml

The result should be combined into a single array containing three columns:
|Date|USD|CAD|
|---|---|---|
|Timestamp|USD|CAD|
|...|...|...|

You will need to parse XML using appropriate modules and convert its related parts into an array representation.

Furthermore, the fetched data should be saved in a SQLite3 database and this database should serve as a cache. 

The ECB data is updated regularly. If new data is available, this data has to be merged into the SQLite3 database.

The SQLite3 database has only one table named **exchange_rate**. The table has the following structure:
```sql
CREATE TABLE exchange_rate (
  timestamp integer,
  usd float,
  cad float
);
````

To be able to merge data, you should lookup the timestamp information in this table and only insert new data if the timestamp does not exist yet. 

You can find the documentation of the PHP files in the doc/build folder. 

The task can be done with ca. 100 lines of code. 

You should use composer to install missing dependencies. The application uses PhpSpeadsheet as a dependency to generate Excel files as an export. 

After you have finished implementing missing methods, please send us the src/app.php file back. 

You have two scenarios to implement the missing methods. 
a) You can use your own webserver + PHP installation.
For this to work, install a webserver + PHP with necessary extensions (for instance gd and zip) and unzip the contents of the ZIP-file into a folder under your documentroot. 
Do not forget to use composer to install the project dependencies. 

b) You can use docker using the provided Dockerfile.
1) change your working directory to the unzipped folder (cd path_to_folder)
2) docker build -t tore-php .
3) docker run -d -p 8080:80 --name tore-php-app tore-php
4) Go to http://127.0.0.1:8080/

Do not forget to use composer in docker to install the project dependencies. 


